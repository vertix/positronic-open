from enum import Enum

class ServiceIds(Enum):
    eIdBaseCyclic = 3
    eIdInterconnectConfig = 14
    eIdInterconnectCyclic = 15
    eIdSession = 1
    eIdDeviceConfig = 9
    eIdDeviceManager = 23
    eIdActuatorCyclic = 11
    eIdActuatorConfig = 10
    eIdBase = 2
    eIdTest = 4080
    eIdGripperCyclic = 17
    eIdVisionConfig = 5
    eIdControlConfig = 16
